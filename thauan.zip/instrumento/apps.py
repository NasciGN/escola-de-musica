from django.apps import AppConfig


class InstrumentoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'instrumento'
