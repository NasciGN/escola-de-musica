from django.apps import AppConfig


class OrquestraConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'orquestra'
